﻿/*
 * .NET bindings for libheif.
 * Copyright (c) 2020, 2021, 2022, 2023 Nicholas Hayes
 *
 * Portions Copyright (c) 2017 struktur AG, Dirk Farin <farin@struktur.de>
 *
 * This file is part of libheif-sharp.
 *
 * libheif-sharp is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * libheif-sharp is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with libheif-sharp.  If not, see <http://www.gnu.org/licenses/>.
 */

namespace LibHeifSharp
{
    /// <summary>
    /// The type of rotation than the image requires.
    /// </summary>
    public enum RotationType
    {
        /// <summary>
        /// The image should not be rotated.
        /// </summary>
        None = 0,

        /// <summary>
        /// The image should be rotated 90 degrees counter-clockwise.
        /// </summary>
        Rotate90DegreesCounterClockwise,

        /// <summary>
        /// The image should be rotated 180 degrees.
        /// </summary>
        Rotate180Degrees,

        /// <summary>
        /// The image should be rotated 270 degrees counter-clockwise.
        /// </summary>
        Rotate270DegreesCounterClockwise,
    }
}
