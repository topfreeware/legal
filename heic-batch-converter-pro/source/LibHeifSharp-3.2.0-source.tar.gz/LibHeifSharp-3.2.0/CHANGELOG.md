# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## v3.2.0 - 2023-11-19

## Added

* Support for reading and writing the inline and reference mask region items.
  * Requires LibHeif 1.17.0 or later.
* `ReadOnlyMemory<byte>` and `ReadOnlySpan<byte>` overloads for various APIs.
  * This adds a `System.Memory` dependency to the .NET Standard 2.0 target.
* An `AsSpan` method to the `HeifIccColorProfile` class.
* A .NET Standard 2.1 target.

## v3.1.0 - 2023-05-16

## Added

* A `ColorConversionOptions` property to the `HeifDecodingOptions` class.
  * Requires LibHeif 1.16.0 or later, it will be ignored on older versions.
* A `ColorConversionOptions` property to the `HeifEncodingOptions` class.
  * Requires LibHeif 1.16.0 or later, it will be ignored on older versions.
* Support for the LibHeif region APIs.
  * A `GetRegionItem` method to the `HeifContext` class.
  * `AddRegion` and `GetRegionItemIds` methods to the `HeifImageHandle` class.
  * These methods require LibHeif 1.16.0 or later.
* Support for the LibHeif item property APIs.
  * `AddUserDescriptionProperty`, `GetTransformationProperties` and `GetUserDescriptionProperties` methods to the `HeifContext` class.
  * These methods require LibHeif 1.16.0 or later.

## Fixed

* The `PixelAspectRatio` property will ignore a default initialized structure.
  * ISO/IEC 14496-12:2015 requires the horizontal and vertical spacing to be positive numbers.

## v3.0.0 - 2023-02-28

## Breaking

* All obsolete members will produce a compiler error.
* Removed the .NET Standard 1.3 and .NET Framework 4.6 targets.

## Added

* A `GetDecoderDescriptors` method to the `LibHeifInfo` class.
  * Requires LibHeif version 1.15.0 or later, it returns an empty collection on older versions.
* A `DecoderId` property to the `HeifDecodingOptions` class.
  * This instructs LibHeif to use a specific decoder when reading the image.
  * Requires LibHeif version 1.15.0 or later, it is ignored on older versions.
* A `HaveVersion` method to the `LibHeifInfo` class.
  * This simplifies checking that LibHeif is at least the specified minimum version. 
* `IccColorProfile` and `NclxColorProfile` properties to the `HeifImageHandle` class.
* A `GetMetadataBlockInfo` method to the `HeifImageHandle` class.
* A `ContentLightLevel` property to the `HeifImage` class.
  * The content light level data is used for HDR rendering.
  * Requires LibHeif version 1.15.0 or later.
* A `MasteringDisplayColourVolume` property to the `HeifImage` class.
  * The mastering display color volume data is used for HDR rendering.
  * Requires LibHeif version 1.15.0 or later.
* A `PixelAspectRatio` property to the `HeifImage` class.
  * Requires LibHeif version 1.15.0 or later.
* An `ImageOrientation` property to the `HeifEncodingOptions` class.
  * This property allows the encoder to convert the EXIF Orientation values into the equivalent HEIF image transformations.
  * Requires LibHeif version 1.14.0 or later, it is ignored on older versions.
  
## Changed

* `GetDepthRepresentationInfo` throws an exception when the nonlinear representation model is larger than 2GB.
  * Previous versions of this library would silently ignore a nonlinear representation model that is larger than 2GB.

## v2.4.0 - 2022-09-10

### Added

* A `SetMaximumDecodingThreads` method to the `HeifContext` class.

## Fixed

* The P/Invoke name used by the `SetMaximumImageSizeLimit` method.
* Various issues with the documentation.

## v2.3.1 - 2022-09-08

### Fixed

* A potential correctness issue in the I/O code.

## v2.3.0 - 2022-09-03

### Added

* A `Strict` property to the `HeifDecodingOptions` class.
  * When enabled, it instructs the decoder to return an error for invalid input.
  * Requires LibHeif version 1.13.0 or later, it is ignored on older versions.
* A `DecodingWarnings` property to the `HeifImage` class.
  * This property returns a collection of warnings that occurred when decoding the image.
  * Requires LibHeif version 1.13.0 or later, it returns an empty collection on older versions.

### Changed

* The libheif initialization and cleanup methods will be called when creating the `HeifContext`.
  * This applies to libheif version 1.13.0 and later, it will be treated as a no-op on older versions.

### Fixed

* Various issues with the documentation.

## v2.2.0 - 2022-02-22

### Added

* An `IsPremultipliedAlpha` property to the `HeifImage` and `HeifImageHandle` classes.
  * This property is supported on LibHeif 1.12 and later.

### Fixed

* A potential crash when creating the `HeifDepthRepresentationInfo`.
* A parameter validation issue when reading zero bytes.

## v2.1.0 - 2021-05-19

### Deprecated

* The `ColorProfile` property in the `HeifImage` class, use the `IccColorProfile` and `NclxColorProfile` properties instead.

### Added

* A `ValidValues` property to the `HeifIntegerEncoderParameter` class.
  * This is used to get the supported values for the rav1e `tile-cols` and `tile-rows` parameters.
  * Requires LibHeif version 1.10 or later.
* Support for the new encoding options in LibHeif versions 1.9.2, 1.10 and 1.11.
* Support for reading and writing images with two color profiles (one ICC profile and one NCLX profile).
   * This feature requires LibHeif version 1.10 or later, you can use the `CanWriteTwoColorProfiles` property in the `LibHeifInfo` class for runtime checks.
   * It must be enabled in the `HeifEncodingOptions` instance by setting the `WriteTwoColorProfiles` property to `true`.
* Support for reading the vendor-specific auxiliary images.
  * Added `GetAuxiliaryImage`, `GetAuxiliaryImageIds` and `GetAuxiliaryType` methods to the `HeifImageHandle` class.
  * These methods require LibHeif version 1.11 or later.
* An `AuxiliaryImageType` property to the `HeifImageHandle` class.

### Fixed

* A corrupted image bug when using lossless encoding.
* A few issues with the documentation.

## v2.0.2 - 2020-12-29

### Fixed

A missing marshaling attribute on the write callback.

## v2.0.1 - 2020-11-24

### Changed

* Reduced memory usage when reading small files.

### Fixed

* A few issues with the documentation.
* A compatibility issue with some classes that are derived from `MemoryStream`.

## v2.0.0 - 2020-11-11

### Breaking

* The `thumbnail` parameter in the `EncodeImage` method has been renamed to `image`.
* `ReadFromMemory` now throws an `ArgumentException` if the array length is zero.
* `AddPlane` now throws an `ArgumentOutOfRangeException` if the `width`, `height` or `bitDepth` parameters are less than or equal to 0.

### Deprecated

* The `ReadFromFile` method, use the `HeifContext(string)` constructor overload instead.
* The `ReadFromMemory` method, use the `HeifContext(byte[])` constructor overload instead.

### Added

* A `SetMaximumImageSizeLimit` method to the `HeifContext` class.
* A `WriteToStream` method to the `HeifContext` class.
* A few `HeifContext` constructor overloads that read the image data.
  * `HeifContext(string)` replaces the `ReadFromFile` method.
  * `HeifContext(byte[])` replaces the `ReadFromMemory` method.
  * `HeifContext(Stream, bool)` reads from a Stream, and optionally leaves the stream open after the HeifContext has been disposed.

### Changed

* The `SetParameter(string, string)` overload will now try to convert Boolean and integer values to the correct type, an exception will be thrown if the conversion fails.
* `GetExifMetadata()` will now return `null` if the TIFF header offset is not valid.
* Mark the `HeifItemId` structure as readonly.
* Reduce memory usage when reading a HEIF image from a byte array.

### Fixed

* A number of issues with the documentation. 

## v1.0.0 - 2020-10-21

### Added

First version

